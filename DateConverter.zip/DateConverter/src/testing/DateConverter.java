package testing;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("input: ");
        String shortDate = scanner.nextLine();

        try {
            SimpleDateFormat sdfInput = new SimpleDateFormat("yyyy-MM-dd");
            Date date = sdfInput.parse(shortDate);

            SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy");
            SimpleDateFormat sdfMonth = new SimpleDateFormat("MM");
            SimpleDateFormat sdfDay = new SimpleDateFormat("dd");

            int year = Integer.parseInt(sdfYear.format(date));
            int month = Integer.parseInt(sdfMonth.format(date));
            int day = Integer.parseInt(sdfDay.format(date));

            String monthName = convertMonthNumberToName(month);

            System.out.println("output: " + monthName + " " + day + ", " + year);

        } catch (ParseException | NumberFormatException e) {
            System.err.println("Invalid date format. Please use YYYY-MM-DD.");
        }
    }

    private static String convertMonthNumberToName(int month) {
        String[] monthNames = {"January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"};

        if (month >= 1 && month <= 12) {
            return monthNames[month - 1];
        } else {
            return "Invalid Month";
        }
    }
}
